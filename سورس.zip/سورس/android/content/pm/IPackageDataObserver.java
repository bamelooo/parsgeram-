package android.content.pm;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IPackageDataObserver extends IInterface {
	public static abstract class Stub extends Binder implements IPackageDataObserver {
		private static final String DESCRIPTOR = "android.content.pm.IPackageDataObserver";
		static final int TRANSACTION_onRemoveCompleted = 1;

		private static class Proxy implements IPackageDataObserver {
			private IBinder mRemote;

			Proxy(IBinder remote) {
				super();
				mRemote = remote;
			}

			public IBinder asBinder() {
				return mRemote;
			}

			public String getInterfaceDescriptor() {
				return DESCRIPTOR;
			}

			public void onRemoveCompleted(String packageName, boolean succeeded) throws RemoteException {
				int r1i = TRANSACTION_onRemoveCompleted;
				Parcel _data = Parcel.obtain();
				_data.writeInterfaceToken(DESCRIPTOR);
				_data.writeString(packageName);
				if (succeeded) {
					_data.writeInt(r1i);
					mRemote.transact(TRANSACTION_onRemoveCompleted, _data, null, TRANSACTION_onRemoveCompleted);
					_data.recycle();
				} else {
					r1i = 0;
					_data.writeInt(r1i);
					mRemote.transact(TRANSACTION_onRemoveCompleted, _data, null, TRANSACTION_onRemoveCompleted);
					_data.recycle();
				}
			}
		}


		public Stub() {
			super();
			attachInterface(this, DESCRIPTOR);
		}

		public static IPackageDataObserver asInterface(IBinder obj) {
			if (obj == null) {
				return null;
			} else {
				IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
				if (iin == null || !(iin instanceof IPackageDataObserver)) {
					return new Proxy(obj);
				} else {
					return (IPackageDataObserver) iin;
				}
			}
		}

		public IBinder asBinder() {
			return this;
		}

		public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
			switch(code) {
			case TRANSACTION_onRemoveCompleted:
				boolean _arg1;
				data.enforceInterface(DESCRIPTOR);
				String _arg0 = data.readString();
				if (data.readInt() != 0) {
					_arg1 = true;
				} else {
					_arg1 = false;
				}
				onRemoveCompleted(_arg0, _arg1);
				return true;
			case 1598968902:
				reply.writeString(DESCRIPTOR);
				return true;
			}
			return super.onTransact(code, data, reply, flags);
		}
	}


	public void onRemoveCompleted(String r1_String, boolean r2z) throws RemoteException;
}
