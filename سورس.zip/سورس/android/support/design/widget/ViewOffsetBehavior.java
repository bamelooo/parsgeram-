package android.support.design.widget;

import android.content.Context;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.util.AttributeSet;
import android.view.View;

class ViewOffsetBehavior<V extends View> extends Behavior<V> {
	private int mTempLeftRightOffset;
	private int mTempTopBottomOffset;
	private ViewOffsetHelper mViewOffsetHelper;

	public ViewOffsetBehavior() {
		super();
		mTempTopBottomOffset = 0;
		mTempLeftRightOffset = 0;
	}

	public ViewOffsetBehavior(Context context, AttributeSet attrs) {
		super(context, attrs);
		mTempTopBottomOffset = 0;
		mTempLeftRightOffset = 0;
	}

	public int getLeftAndRightOffset() {
		if (mViewOffsetHelper != null) {
			return mViewOffsetHelper.getLeftAndRightOffset();
		} else {
			return 0;
		}
	}

	public int getTopAndBottomOffset() {
		if (mViewOffsetHelper != null) {
			return mViewOffsetHelper.getTopAndBottomOffset();
		} else {
			return 0;
		}
	}

	protected void layoutChild(CoordinatorLayout parent, V child, int layoutDirection) {
		parent.onLayoutChild(child, layoutDirection);
	}

	public boolean onLayoutChild(CoordinatorLayout parent, V child, int layoutDirection) {
		layoutChild(parent, child, layoutDirection);
		if (mViewOffsetHelper == null) {
			mViewOffsetHelper = new ViewOffsetHelper(child);
		}
		mViewOffsetHelper.onViewLayout();
		if (mTempTopBottomOffset != 0) {
			mViewOffsetHelper.setTopAndBottomOffset(mTempTopBottomOffset);
			mTempTopBottomOffset = 0;
		}
		if (mTempLeftRightOffset != 0) {
			mViewOffsetHelper.setLeftAndRightOffset(mTempLeftRightOffset);
			mTempLeftRightOffset = 0;
		}
		return true;
	}

	public boolean setLeftAndRightOffset(int offset) {
		if (mViewOffsetHelper != null) {
			return mViewOffsetHelper.setLeftAndRightOffset(offset);
		} else {
			mTempLeftRightOffset = offset;
			return false;
		}
	}

	public boolean setTopAndBottomOffset(int offset) {
		if (mViewOffsetHelper != null) {
			return mViewOffsetHelper.setTopAndBottomOffset(offset);
		} else {
			mTempTopBottomOffset = offset;
			return false;
		}
	}
}
