package android.support.design.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.design.widget.CoordinatorLayout.LayoutParams;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import java.util.List;
import org.telegram.tgnet.TLRPC;

abstract class HeaderScrollingViewBehavior extends ViewOffsetBehavior<View> {
	private int mOverlayTop;
	final Rect mTempRect1;
	final Rect mTempRect2;
	private int mVerticalLayoutGap;

	public HeaderScrollingViewBehavior() {
		super();
		mTempRect1 = new Rect();
		mTempRect2 = new Rect();
		mVerticalLayoutGap = 0;
	}

	public HeaderScrollingViewBehavior(Context context, AttributeSet attrs) {
		super(context, attrs);
		mTempRect1 = new Rect();
		mTempRect2 = new Rect();
		mVerticalLayoutGap = 0;
	}

	private static int resolveGravity(int gravity) {
		if (gravity == 0) {
			gravity = 8388659;
		}
		return gravity;
	}

	abstract View findFirstDependency(List<View> r1_List_View);

	final int getOverlapPixelsForOffset(View header) {
		int r0i = 0;
		if (mOverlayTop == 0) {
			return 0;
		} else {
			return MathUtils.constrain((int) (getOverlapRatioForOffset(header) * ((float) mOverlayTop)), r0i, mOverlayTop);
		}
	}

	float getOverlapRatioForOffset(View header) {
		return 1.0f;
	}

	public final int getOverlayTop() {
		return mOverlayTop;
	}

	int getScrollRange(View v) {
		return v.getMeasuredHeight();
	}

	final int getVerticalLayoutGap() {
		return mVerticalLayoutGap;
	}

	protected void layoutChild(CoordinatorLayout parent, View child, int layoutDirection) {
		View header = findFirstDependency(parent.getDependencies(child));
		if (header != null) {
			LayoutParams lp = (LayoutParams) child.getLayoutParams();
			Rect available = mTempRect1;
			available.set(parent.getPaddingLeft() + lp.leftMargin, header.getBottom() + lp.topMargin, (parent.getWidth() - parent.getPaddingRight()) - lp.rightMargin, ((parent.getHeight() + header.getBottom()) - parent.getPaddingBottom()) - lp.bottomMargin);
			WindowInsetsCompat parentInsets = parent.getLastWindowInsets();
			Rect out;
			int overlap;
			if (parentInsets == null || !ViewCompat.getFitsSystemWindows(parent) || ViewCompat.getFitsSystemWindows(child)) {
				out = mTempRect2;
				GravityCompat.apply(resolveGravity(lp.gravity), child.getMeasuredWidth(), child.getMeasuredHeight(), available, out, layoutDirection);
				overlap = getOverlapPixelsForOffset(header);
				child.layout(out.left, out.top - overlap, out.right, out.bottom - overlap);
				mVerticalLayoutGap = out.top - header.getBottom();
			} else {
				available.left += parentInsets.getSystemWindowInsetLeft();
				available.right -= parentInsets.getSystemWindowInsetRight();
				out = mTempRect2;
				GravityCompat.apply(resolveGravity(lp.gravity), child.getMeasuredWidth(), child.getMeasuredHeight(), available, out, layoutDirection);
				overlap = getOverlapPixelsForOffset(header);
				child.layout(out.left, out.top - overlap, out.right, out.bottom - overlap);
				mVerticalLayoutGap = out.top - header.getBottom();
			}
		} else {
			super.layoutChild(parent, child, layoutDirection);
			mVerticalLayoutGap = 0;
		}
	}

	public boolean onMeasureChild(CoordinatorLayout parent, View child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed) {
		int childLpHeight = child.getLayoutParams().height;
		if (childLpHeight == -1 || childLpHeight == -2) {
			View header = findFirstDependency(parent.getDependencies(child));
			if (header != null) {
				int availableHeight;
				int height;
				int r0i;
				if (!ViewCompat.getFitsSystemWindows(header) || ViewCompat.getFitsSystemWindows(child)) {
					availableHeight = MeasureSpec.getSize(parentHeightMeasureSpec);
					if (availableHeight != 0) {
						availableHeight = parent.getHeight();
					}
					height = (availableHeight - header.getMeasuredHeight()) + getScrollRange(header);
					if (childLpHeight == -1) {
						r0i = 1073741824;
					} else {
						r0i = TLRPC.MESSAGE_FLAG_MEGAGROUP;
					}
					parent.onMeasureChild(child, parentWidthMeasureSpec, widthUsed, MeasureSpec.makeMeasureSpec(height, r0i), heightUsed);
					return true;
				} else {
					ViewCompat.setFitsSystemWindows(child, true);
					if (ViewCompat.getFitsSystemWindows(child)) {
						child.requestLayout();
						return true;
					}
					availableHeight = MeasureSpec.getSize(parentHeightMeasureSpec);
					if (availableHeight != 0) {
						height = (availableHeight - header.getMeasuredHeight()) + getScrollRange(header);
						if (childLpHeight == -1) {
							r0i = TLRPC.MESSAGE_FLAG_MEGAGROUP;
						} else {
							r0i = 1073741824;
						}
						parent.onMeasureChild(child, parentWidthMeasureSpec, widthUsed, MeasureSpec.makeMeasureSpec(height, r0i), heightUsed);
						return true;
					} else {
						availableHeight = parent.getHeight();
						height = (availableHeight - header.getMeasuredHeight()) + getScrollRange(header);
						if (childLpHeight == -1) {
							r0i = 1073741824;
						} else {
							r0i = TLRPC.MESSAGE_FLAG_MEGAGROUP;
						}
						parent.onMeasureChild(child, parentWidthMeasureSpec, widthUsed, MeasureSpec.makeMeasureSpec(height, r0i), heightUsed);
						return true;
					}
				}
			}
		} else {
			return false;
		}
		return false;
	}

	public final void setOverlayTop(int overlayTop) {
		mOverlayTop = overlayTop;
	}
}
