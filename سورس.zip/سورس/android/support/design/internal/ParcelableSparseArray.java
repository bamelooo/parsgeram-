package android.support.design.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.util.SparseArray;

public class ParcelableSparseArray extends SparseArray<Parcelable> implements Parcelable {
	public static final Creator<ParcelableSparseArray> CREATOR;

	static class AnonymousClass_1 implements ParcelableCompatCreatorCallbacks<ParcelableSparseArray> {
		AnonymousClass_1() {
			super();
		}

		public ParcelableSparseArray createFromParcel(Parcel source, ClassLoader loader) {
			return new ParcelableSparseArray(source, loader);
		}

		public ParcelableSparseArray[] newArray(int size) {
			return new ParcelableSparseArray[size];
		}
	}


	static {
		CREATOR = ParcelableCompat.newCreator(new AnonymousClass_1());
	}

	public ParcelableSparseArray() {
		super();
	}

	public ParcelableSparseArray(Parcel source, ClassLoader loader) {
		super();
		int size = source.readInt();
		int[] keys = new int[size];
		source.readIntArray(keys);
		Parcelable[] values = source.readParcelableArray(loader);
		int i = 0;
		while (i < size) {
			put(keys[i], values[i]);
			i++;
		}
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel parcel, int flags) {
		int size = size();
		int[] keys = new int[size];
		Parcelable[] values = new Parcelable[size];
		int i = 0;
		while (i < size) {
			keys[i] = keyAt(i);
			values[i] = (Parcelable) valueAt(i);
			i++;
		}
		parcel.writeInt(size);
		parcel.writeIntArray(keys);
		parcel.writeParcelableArray(values, flags);
	}
}
