package android.support.v7.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.view.ActionProvider;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.appcompat.R;
import android.util.SparseArray;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyCharacterMap.KeyData;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class MenuBuilder implements SupportMenu {
	private static final String ACTION_VIEW_STATES_KEY = "android:menu:actionviewstates";
	private static final String EXPANDED_ACTION_VIEW_ID = "android:menu:expandedactionview";
	private static final String PRESENTER_KEY = "android:menu:presenters";
	private static final String TAG = "MenuBuilder";
	private static final int[] sCategoryToOrder;
	private ArrayList<MenuItemImpl> mActionItems;
	private Callback mCallback;
	private final Context mContext;
	private ContextMenuInfo mCurrentMenuInfo;
	private int mDefaultShowAsAction;
	private MenuItemImpl mExpandedItem;
	private SparseArray<Parcelable> mFrozenViewStates;
	Drawable mHeaderIcon;
	CharSequence mHeaderTitle;
	View mHeaderView;
	private boolean mIsActionItemsStale;
	private boolean mIsClosing;
	private boolean mIsVisibleItemsStale;
	private ArrayList<MenuItemImpl> mItems;
	private boolean mItemsChangedWhileDispatchPrevented;
	private ArrayList<MenuItemImpl> mNonActionItems;
	private boolean mOptionalIconsVisible;
	private boolean mOverrideVisibleItems;
	private CopyOnWriteArrayList<WeakReference<MenuPresenter>> mPresenters;
	private boolean mPreventDispatchingItemsChanged;
	private boolean mQwertyMode;
	private final Resources mResources;
	private boolean mShortcutsVisible;
	private ArrayList<MenuItemImpl> mTempShortcutItemList;
	private ArrayList<MenuItemImpl> mVisibleItems;

	public static interface Callback {
		public boolean onMenuItemSelected(MenuBuilder r1_MenuBuilder, MenuItem r2_MenuItem);

		public void onMenuModeChange(MenuBuilder r1_MenuBuilder);
	}

	public static interface ItemInvoker {
		public boolean invokeItem(MenuItemImpl r1_MenuItemImpl);
	}


	static {
		sCategoryToOrder = new int[]{1, 4, 5, 3, 2, 0};
	}

	public MenuBuilder(Context context) {
		super();
		mDefaultShowAsAction = 0;
		mPreventDispatchingItemsChanged = false;
		mItemsChangedWhileDispatchPrevented = false;
		mOptionalIconsVisible = false;
		mIsClosing = false;
		mTempShortcutItemList = new ArrayList();
		mPresenters = new CopyOnWriteArrayList();
		mContext = context;
		mResources = context.getResources();
		mItems = new ArrayList();
		mVisibleItems = new ArrayList();
		mIsVisibleItemsStale = true;
		mActionItems = new ArrayList();
		mNonActionItems = new ArrayList();
		mIsActionItemsStale = true;
		setShortcutsVisibleInner(true);
	}

	private MenuItemImpl createNewMenuItem(int group, int id, int categoryOrder, int ordering, CharSequence title, int defaultShowAsAction) {
		return new MenuItemImpl(this, group, id, categoryOrder, ordering, title, defaultShowAsAction);
	}

	private void dispatchPresenterUpdate(boolean cleared) {
		if (mPresenters.isEmpty()) {
		} else {
			stopDispatchingItemsChanged();
			Iterator r2_Iterator = mPresenters.iterator();
			while (r2_Iterator.hasNext()) {
				WeakReference<MenuPresenter> ref = (WeakReference) r2_Iterator.next();
				MenuPresenter presenter = (MenuPresenter) ref.get();
				if (presenter == null) {
					mPresenters.remove(ref);
				} else {
					presenter.updateMenuView(cleared);
				}
			}
			startDispatchingItemsChanged();
		}
	}

	private void dispatchRestoreInstanceState(Bundle state) {
		SparseArray<Parcelable> presenterStates = state.getSparseParcelableArray(PRESENTER_KEY);
		if (presenterStates == null || mPresenters.isEmpty()) {
		} else {
			Iterator r5_Iterator = mPresenters.iterator();
			while (r5_Iterator.hasNext()) {
				WeakReference<MenuPresenter> ref = (WeakReference) r5_Iterator.next();
				MenuPresenter presenter = (MenuPresenter) ref.get();
				if (presenter == null) {
					mPresenters.remove(ref);
				} else {
					int id = presenter.getId();
					if (id > 0) {
						Parcelable parcel = (Parcelable) presenterStates.get(id);
						if (parcel != null) {
							presenter.onRestoreInstanceState(parcel);
						}
					}
				}
			}
		}
	}

	private void dispatchSaveInstanceState(Bundle outState) {
		if (mPresenters.isEmpty()) {
		} else {
			SparseArray<Parcelable> presenterStates = new SparseArray();
			Iterator r5_Iterator = mPresenters.iterator();
			while (r5_Iterator.hasNext()) {
				WeakReference<MenuPresenter> ref = (WeakReference) r5_Iterator.next();
				MenuPresenter presenter = (MenuPresenter) ref.get();
				if (presenter == null) {
					mPresenters.remove(ref);
				} else {
					int id = presenter.getId();
					if (id > 0) {
						Parcelable state = presenter.onSaveInstanceState();
						if (state != null) {
							presenterStates.put(id, state);
						}
					}
				}
			}
			outState.putSparseParcelableArray(PRESENTER_KEY, presenterStates);
		}
	}

	private boolean dispatchSubMenuSelected(SubMenuBuilder subMenu, MenuPresenter preferredPresenter) {
		if (mPresenters.isEmpty()) {
			return false;
		} else {
			boolean result = false;
			if (preferredPresenter != null) {
				result = preferredPresenter.onSubMenuSelected(subMenu);
			}
			Iterator r3_Iterator = mPresenters.iterator();
			while (r3_Iterator.hasNext()) {
				WeakReference<MenuPresenter> ref = (WeakReference) r3_Iterator.next();
				MenuPresenter presenter = (MenuPresenter) ref.get();
				if (presenter == null) {
					mPresenters.remove(ref);
				} else if (!result) {
					result = presenter.onSubMenuSelected(subMenu);
				}
			}
			return result;
		}
	}

	private static int findInsertIndex(ArrayList<MenuItemImpl> items, int ordering) {
		int i = items.size() - 1;
		while (i >= 0) {
			if (((MenuItemImpl) items.get(i)).getOrdering() <= ordering) {
				return i + 1;
			} else {
				i--;
			}
		}
		return 0;
	}

	private static int getOrdering(int categoryOrder) {
		int index = (-65536 & categoryOrder) >> 16;
		if (index < 0 || index >= sCategoryToOrder.length) {
			throw new IllegalArgumentException("order does not contain a valid category.");
		} else {
			return (sCategoryToOrder[index] << 16) | (65535 & categoryOrder);
		}
	}

	private void removeItemAtInt(int index, boolean updateChildrenOnMenuViews) {
		if (index < 0 || index >= mItems.size()) {
		} else {
			mItems.remove(index);
			if (updateChildrenOnMenuViews) {
				onItemsChanged(true);
			}
		}
	}

	private void setHeaderInternal(int titleRes, CharSequence title, int iconRes, Drawable icon, View view) {
		Resources r = getResources();
		if (view != null) {
			mHeaderView = view;
			mHeaderTitle = null;
			mHeaderIcon = null;
		} else {
			if (titleRes > 0) {
				mHeaderTitle = r.getText(titleRes);
			} else if (title != null) {
				mHeaderTitle = title;
			}
			if (iconRes > 0) {
				mHeaderIcon = ContextCompat.getDrawable(getContext(), iconRes);
			} else if (icon != null) {
				mHeaderIcon = icon;
			}
			mHeaderView = null;
		}
		onItemsChanged(false);
	}

	private void setShortcutsVisibleInner(boolean shortcutsVisible) {
		boolean r0z = true;
		if (!shortcutsVisible || mResources.getConfiguration().keyboard == 1 || !mResources.getBoolean(R.bool.abc_config_showMenuShortcutsWhenKeyboardPresent)) {
			r0z = false;
		} else {
			mShortcutsVisible = r0z;
		}
		mShortcutsVisible = r0z;
	}

	public MenuItem add(int titleRes) {
		return addInternal(0, 0, 0, mResources.getString(titleRes));
	}

	public MenuItem add(int group, int id, int categoryOrder, int title) {
		return addInternal(group, id, categoryOrder, mResources.getString(title));
	}

	public MenuItem add(int group, int id, int categoryOrder, CharSequence title) {
		return addInternal(group, id, categoryOrder, title);
	}

	public MenuItem add(CharSequence title) {
		return addInternal(0, 0, 0, title);
	}

	public int addIntentOptions(int group, int id, int categoryOrder, ComponentName caller, Intent[] specifics, Intent intent, int flags, MenuItem[] outSpecificItems) {
		int N;
		PackageManager pm = mContext.getPackageManager();
		List<ResolveInfo> lri = pm.queryIntentActivityOptions(caller, specifics, intent, 0);
		if (lri != null) {
			N = lri.size();
		} else {
			N = 0;
		}
		if ((flags & 1) == 0) {
			removeGroup(group);
		}
		int i = 0;
		while (i < N) {
			Intent r10_Intent;
			ResolveInfo ri = (ResolveInfo) lri.get(i);
			if (ri.specificIndex < 0) {
				r10_Intent = intent;
			} else {
				r10_Intent = specifics[ri.specificIndex];
			}
			Intent rintent = new Intent(r10_Intent);
			rintent.setComponent(new ComponentName(ri.activityInfo.applicationInfo.packageName, ri.activityInfo.name));
			MenuItem item = add(group, id, categoryOrder, ri.loadLabel(pm)).setIcon(ri.loadIcon(pm)).setIntent(rintent);
			if (outSpecificItems == null || ri.specificIndex < 0) {
				i++;
			} else {
				outSpecificItems[ri.specificIndex] = item;
				i++;
			}
		}
		return N;
	}

	protected MenuItem addInternal(int group, int id, int categoryOrder, CharSequence title) {
		int ordering = getOrdering(categoryOrder);
		MenuItemImpl item = createNewMenuItem(group, id, categoryOrder, ordering, title, mDefaultShowAsAction);
		if (mCurrentMenuInfo != null) {
			item.setMenuInfo(mCurrentMenuInfo);
		}
		mItems.add(findInsertIndex(mItems, ordering), item);
		onItemsChanged(true);
		return item;
	}

	public void addMenuPresenter(MenuPresenter presenter) {
		addMenuPresenter(presenter, mContext);
	}

	public void addMenuPresenter(MenuPresenter presenter, Context menuContext) {
		mPresenters.add(new WeakReference(presenter));
		presenter.initForMenu(menuContext, this);
		mIsActionItemsStale = true;
	}

	public SubMenu addSubMenu(int titleRes) {
		return addSubMenu(0, 0, 0, mResources.getString(titleRes));
	}

	public SubMenu addSubMenu(int group, int id, int categoryOrder, int title) {
		return addSubMenu(group, id, categoryOrder, mResources.getString(title));
	}

	public SubMenu addSubMenu(int group, int id, int categoryOrder, CharSequence title) {
		MenuItemImpl item = (MenuItemImpl) addInternal(group, id, categoryOrder, title);
		SubMenuBuilder subMenu = new SubMenuBuilder(mContext, this, item);
		item.setSubMenu(subMenu);
		return subMenu;
	}

	public SubMenu addSubMenu(CharSequence title) {
		return addSubMenu(0, 0, 0, title);
	}

	public void changeMenuMode() {
		if (mCallback != null) {
			mCallback.onMenuModeChange(this);
		}
	}

	public void clear() {
		if (mExpandedItem != null) {
			collapseItemActionView(mExpandedItem);
		}
		mItems.clear();
		onItemsChanged(true);
	}

	public void clearAll() {
		mPreventDispatchingItemsChanged = true;
		clear();
		clearHeader();
		mPreventDispatchingItemsChanged = false;
		mItemsChangedWhileDispatchPrevented = false;
		onItemsChanged(true);
	}

	public void clearHeader() {
		mHeaderIcon = null;
		mHeaderTitle = null;
		mHeaderView = null;
		onItemsChanged(false);
	}

	public void close() {
		close(true);
	}

	public final void close(boolean closeAllMenus) {
		if (mIsClosing) {
		} else {
			mIsClosing = true;
			Iterator r2_Iterator = mPresenters.iterator();
			while (r2_Iterator.hasNext()) {
				WeakReference<MenuPresenter> ref = (WeakReference) r2_Iterator.next();
				MenuPresenter presenter = (MenuPresenter) ref.get();
				if (presenter == null) {
					mPresenters.remove(ref);
				} else {
					presenter.onCloseMenu(this, closeAllMenus);
				}
			}
			mIsClosing = false;
		}
	}

	public boolean collapseItemActionView(MenuItemImpl item) {
		if (mPresenters.isEmpty() || mExpandedItem != item) {
			return false;
		} else {
			boolean collapsed = false;
			stopDispatchingItemsChanged();
			Iterator r3_Iterator = mPresenters.iterator();
			while (r3_Iterator.hasNext()) {
				WeakReference<MenuPresenter> ref = (WeakReference) r3_Iterator.next();
				MenuPresenter presenter = (MenuPresenter) ref.get();
				if (presenter == null) {
					mPresenters.remove(ref);
				} else {
					collapsed = presenter.collapseItemActionView(this, item);
					if (collapsed) {
						startDispatchingItemsChanged();
					}
				}
			}
			startDispatchingItemsChanged();
			if (collapsed) {
				mExpandedItem = null;
				return collapsed;
			} else {
				return collapsed;
			}
		}
	}

	boolean dispatchMenuItemSelected(MenuBuilder menu, MenuItem item) {
		if (mCallback == null || !mCallback.onMenuItemSelected(menu, item)) {
			return false;
		} else {
			return true;
		}
	}

	public boolean expandItemActionView(MenuItemImpl item) {
		if (mPresenters.isEmpty()) {
			return false;
		} else {
			boolean expanded = false;
			stopDispatchingItemsChanged();
			Iterator r3_Iterator = mPresenters.iterator();
			while (r3_Iterator.hasNext()) {
				WeakReference<MenuPresenter> ref = (WeakReference) r3_Iterator.next();
				MenuPresenter presenter = (MenuPresenter) ref.get();
				if (presenter == null) {
					mPresenters.remove(ref);
				} else {
					expanded = presenter.expandItemActionView(this, item);
					if (expanded) {
						startDispatchingItemsChanged();
					}
				}
			}
			startDispatchingItemsChanged();
			if (expanded) {
				mExpandedItem = item;
				return expanded;
			} else {
				return expanded;
			}
		}
	}

	public int findGroupIndex(int group) {
		return findGroupIndex(group, 0);
	}

	public int findGroupIndex(int group, int start) {
		int size = size();
		if (start < 0) {
			start = 0;
		}
		int i = start;
		while (i < size) {
			if (((MenuItemImpl) mItems.get(i)).getGroupId() == group) {
				return i;
			} else {
				i++;
			}
		}
		return -1;
	}

	public MenuItem findItem(int id) {
		int i = 0;
		while (i < size()) {
			MenuItemImpl item = (MenuItemImpl) mItems.get(i);
			if (item.getItemId() == id) {
				return item;
			} else {
				if (item.hasSubMenu()) {
					MenuItem possibleItem = item.getSubMenu().findItem(id);
					if (possibleItem != null) {
						return possibleItem;
					}
				}
				i++;
			}
		}
		return null;
	}

	public int findItemIndex(int id) {
		int i = 0;
		while (i < size()) {
			if (((MenuItemImpl) mItems.get(i)).getItemId() == id) {
				return i;
			} else {
				i++;
			}
		}
		return -1;
	}

	/* JADX WARNING: inconsistent code */
	/*
	android.support.v7.view.menu.MenuItemImpl findItemWithShortcutForKey(int r13_keyCode, android.view.KeyEvent r14_event) {
		r12_this = this;
		r8 = 0;
		r11 = 0;
		r2 = r12.mTempShortcutItemList;
		r2_items.clear();
		r12.findItemsWithShortcutForKey(r2_items, r13_keyCode, r14_event);
		r9 = r2_items.isEmpty();
		if (r9 == 0) goto L_0x0011;
	L_0x0010:
		return r8;
	L_0x0011:
		r3 = r14_event.getMetaState();
		r4 = new android.view.KeyCharacterMap$KeyData;
		r4.<init>();
		r14_event.getKeyData(r4_possibleChars);
		r7 = r2_items.size();
		r9 = 1;
		if (r7_size != r9) goto L_0x002b;
	L_0x0024:
		r8 = r2_items.get(r11);
		r8 = (android.support.v7.view.menu.MenuItemImpl) r8;
		goto L_0x0010;
	L_0x002b:
		r5 = r12.isQwertyMode();
		r0 = 0;
	L_0x0030:
		if (r0_i >= r7_size) goto L_0x0010;
	L_0x0032:
		r1 = r2_items.get(r0_i);
		r1 = (android.support.v7.view.menu.MenuItemImpl) r1;
		if (r5_qwerty == 0) goto L_0x005f;
	L_0x003a:
		r6 = r1_item.getAlphabeticShortcut();
	L_0x003e:
		r9 = r4_possibleChars.meta;
		r9 = r9[r11];
		if (r6_shortcutChar != r9) goto L_0x0048;
	L_0x0044:
		r9 = r3_metaState & 2;
		if (r9 == 0) goto L_0x005d;
	L_0x0048:
		r9 = r4_possibleChars.meta;
		r10 = 2;
		r9 = r9[r10];
		if (r6_shortcutChar != r9) goto L_0x0053;
	L_0x004f:
		r9 = r3_metaState & 2;
		if (r9 != 0) goto L_0x005d;
	L_0x0053:
		if (r5_qwerty == 0) goto L_0x0064;
	L_0x0055:
		r9 = 8;
		if (r6_shortcutChar != r9) goto L_0x0064;
	L_0x0059:
		r9 = 67;
		if (r13_keyCode != r9) goto L_0x0064;
	L_0x005d:
		r8 = r1_item;
		goto L_0x0010;
	L_0x005f:
		r6_shortcutChar = r1_item.getNumericShortcut();
		goto L_0x003e;
	L_0x0064:
		r0_i++;
		goto L_0x0030;
	}
	*/
	MenuItemImpl findItemWithShortcutForKey(int keyCode, KeyEvent event) {
		ArrayList<MenuItemImpl> items = mTempShortcutItemList;
		items.clear();
		findItemsWithShortcutForKey(items, keyCode, event);
		if (items.isEmpty()) {
			return null;
		} else {
			int metaState = event.getMetaState();
			KeyData possibleChars = new KeyData();
			event.getKeyData(possibleChars);
			int size = items.size();
			if (size == 1) {
				return (MenuItemImpl) items.get(0);
			} else {
				boolean qwerty = isQwertyMode();
				int i = 0;
				while (i < size) {
					char shortcutChar;
					MenuItemImpl item = (MenuItemImpl) items.get(i);
					if (qwerty) {
						shortcutChar = item.getAlphabeticShortcut();
					} else {
						shortcutChar = item.getNumericShortcut();
					}
					if (shortcutChar != possibleChars.meta[0] || (metaState & 2) != 0) {
						if (shortcutChar != possibleChars.meta[2] || (metaState & 2) == 0) {
							i++;
						}
					} else {
						return item;
					}
					return item;
				}
				return null;
			}
		}
	}

	void findItemsWithShortcutForKey(List<MenuItemImpl> items, int keyCode, KeyEvent event) {
		boolean qwerty = isQwertyMode();
		int metaState = event.getMetaState();
		KeyData possibleChars = new KeyData();
		if (event.getKeyData(possibleChars) || keyCode == 67) {
			int i = 0;
			while (i < mItems.size()) {
				char shortcutChar;
				MenuItemImpl item = (MenuItemImpl) mItems.get(i);
				if (item.hasSubMenu()) {
					((MenuBuilder) item.getSubMenu()).findItemsWithShortcutForKey(items, keyCode, event);
				}
				if (qwerty) {
					shortcutChar = item.getAlphabeticShortcut();
				} else {
					shortcutChar = item.getNumericShortcut();
				}
				if ((metaState & 5) != 0 || shortcutChar == '\u0000') {
					i++;
				} else if (shortcutChar == possibleChars.meta[0] || shortcutChar == possibleChars.meta[2]) {
					if (!item.isEnabled()) {
						items.add(item);
					}
					i++;
				} else if (!qwerty || shortcutChar != '\b' || keyCode != 67 || !item.isEnabled()) {
					i++;
				} else {
					items.add(item);
					i++;
				}
			}
		}
	}

	public void flagActionItems() {
		ArrayList<MenuItemImpl> visibleItems = getVisibleItems();
		if (!mIsActionItemsStale) {
		} else {
			boolean flagged = false;
			Iterator r7_Iterator = mPresenters.iterator();
			while (r7_Iterator.hasNext()) {
				WeakReference<MenuPresenter> ref = (WeakReference) r7_Iterator.next();
				MenuPresenter presenter = (MenuPresenter) ref.get();
				if (presenter == null) {
					mPresenters.remove(ref);
				} else {
					flagged |= presenter.flagActionItems();
				}
			}
			if (flagged) {
				mActionItems.clear();
				mNonActionItems.clear();
				int i = 0;
				while (i < visibleItems.size()) {
					MenuItemImpl item = (MenuItemImpl) visibleItems.get(i);
					if (item.isActionButton()) {
						mActionItems.add(item);
					} else {
						mNonActionItems.add(item);
					}
					i++;
				}
			} else {
				mActionItems.clear();
				mNonActionItems.clear();
				mNonActionItems.addAll(getVisibleItems());
			}
			mIsActionItemsStale = false;
		}
	}

	public ArrayList<MenuItemImpl> getActionItems() {
		flagActionItems();
		return mActionItems;
	}

	protected String getActionViewStatesKey() {
		return ACTION_VIEW_STATES_KEY;
	}

	public Context getContext() {
		return mContext;
	}

	public MenuItemImpl getExpandedItem() {
		return mExpandedItem;
	}

	public Drawable getHeaderIcon() {
		return mHeaderIcon;
	}

	public CharSequence getHeaderTitle() {
		return mHeaderTitle;
	}

	public View getHeaderView() {
		return mHeaderView;
	}

	public MenuItem getItem(int index) {
		return (MenuItem) mItems.get(index);
	}

	public ArrayList<MenuItemImpl> getNonActionItems() {
		flagActionItems();
		return mNonActionItems;
	}

	boolean getOptionalIconsVisible() {
		return mOptionalIconsVisible;
	}

	Resources getResources() {
		return mResources;
	}

	public MenuBuilder getRootMenu() {
		return this;
	}

	@NonNull
	public ArrayList<MenuItemImpl> getVisibleItems() {
		if (!mIsVisibleItemsStale) {
			return mVisibleItems;
		} else {
			mVisibleItems.clear();
			int i = 0;
			while (i < mItems.size()) {
				MenuItemImpl item = (MenuItemImpl) mItems.get(i);
				if (item.isVisible()) {
					mVisibleItems.add(item);
				}
				i++;
			}
			mIsVisibleItemsStale = false;
			mIsActionItemsStale = true;
			return mVisibleItems;
		}
	}

	/* JADX WARNING: inconsistent code */
	/*
	public boolean hasVisibleItems() {
		r5_this = this;
		r3 = 1;
		r4 = r5.mOverrideVisibleItems;
		if (r4 == 0) goto L_0x0006;
	L_0x0005:
		return r3;
	L_0x0006:
		r2 = r5.size();
		r0 = 0;
	L_0x000b:
		if (r0_i >= r2_size) goto L_0x001e;
	L_0x000d:
		r4 = r5.mItems;
		r1 = r4.get(r0_i);
		r1 = (android.support.v7.view.menu.MenuItemImpl) r1;
		r4 = r1_item.isVisible();
		if (r4 != 0) goto L_0x0005;
	L_0x001b:
		r0_i++;
		goto L_0x000b;
	L_0x001e:
		r3 = 0;
		goto L_0x0005;
	}
	*/
	public boolean hasVisibleItems() {
		if (mOverrideVisibleItems) {
			return true;
		} else {
			int i = 0;
			while (i < size()) {
				if (!((MenuItemImpl) mItems.get(i)).isVisible()) {
					i++;
				}
			}
			return false;
		}
	}

	boolean isQwertyMode() {
		return mQwertyMode;
	}

	public boolean isShortcutKey(int keyCode, KeyEvent event) {
		if (findItemWithShortcutForKey(keyCode, event) != null) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isShortcutsVisible() {
		return mShortcutsVisible;
	}

	void onItemActionRequestChanged(MenuItemImpl item) {
		mIsActionItemsStale = true;
		onItemsChanged(true);
	}

	void onItemVisibleChanged(MenuItemImpl item) {
		mIsVisibleItemsStale = true;
		onItemsChanged(true);
	}

	public void onItemsChanged(boolean structureChanged) {
		if (!mPreventDispatchingItemsChanged) {
			if (structureChanged) {
				mIsVisibleItemsStale = true;
				mIsActionItemsStale = true;
			}
			dispatchPresenterUpdate(structureChanged);
		} else {
			mItemsChangedWhileDispatchPrevented = true;
		}
	}

	public boolean performIdentifierAction(int id, int flags) {
		return performItemAction(findItem(id), flags);
	}

	public boolean performItemAction(MenuItem item, int flags) {
		return performItemAction(item, null, flags);
	}

	public boolean performItemAction(MenuItem item, MenuPresenter preferredPresenter, int flags) {
		MenuItemImpl itemImpl = (MenuItemImpl) item;
		if (itemImpl == null || !itemImpl.isEnabled()) {
			return false;
		} else {
			boolean providerHasSubMenu;
			boolean invoked = itemImpl.invoke();
			ActionProvider provider = itemImpl.getSupportActionProvider();
			if (provider == null || !provider.hasSubMenu()) {
				providerHasSubMenu = false;
			} else {
				providerHasSubMenu = true;
			}
			if (itemImpl.hasCollapsibleActionView()) {
				invoked |= itemImpl.expandActionView();
				if (invoked) {
					close(true);
					return invoked;
				} else {
					return invoked;
				}
			} else if (itemImpl.hasSubMenu() || providerHasSubMenu) {
				if ((flags & 4) == 0) {
					close(false);
				}
				if (!itemImpl.hasSubMenu()) {
					itemImpl.setSubMenu(new SubMenuBuilder(getContext(), this, itemImpl));
				}
				SubMenuBuilder subMenu = (SubMenuBuilder) itemImpl.getSubMenu();
				if (providerHasSubMenu) {
					provider.onPrepareSubMenu(subMenu);
				}
				invoked |= dispatchSubMenuSelected(subMenu, preferredPresenter);
				if (!invoked) {
					close(true);
					return invoked;
				} else {
					return invoked;
				}
			} else if ((flags & 1) == 0) {
				close(true);
				return invoked;
			} else {
				return invoked;
			}
		}
	}

	public boolean performShortcut(int keyCode, KeyEvent event, int flags) {
		MenuItemImpl item = findItemWithShortcutForKey(keyCode, event);
		boolean handled = false;
		if (item != null) {
			handled = performItemAction(item, flags);
		}
		if ((flags & 2) != 0) {
			close(true);
		}
		return handled;
	}

	public void removeGroup(int group) {
		int i = findGroupIndex(group);
		if (i >= 0) {
			int maxRemovable = mItems.size() - i;
			int numRemoved = 0;
			while (true) {
				int numRemoved_2 = numRemoved + 1;
				if (numRemoved >= maxRemovable || ((MenuItemImpl) mItems.get(i)).getGroupId() != group) {
					onItemsChanged(true);
				} else {
					removeItemAtInt(i, false);
					numRemoved = numRemoved_2;
				}
			}
		}
	}

	public void removeItem(int id) {
		removeItemAtInt(findItemIndex(id), true);
	}

	public void removeItemAt(int index) {
		removeItemAtInt(index, true);
	}

	public void removeMenuPresenter(MenuPresenter presenter) {
		Iterator r2_Iterator = mPresenters.iterator();
		while (r2_Iterator.hasNext()) {
			WeakReference<MenuPresenter> ref = (WeakReference) r2_Iterator.next();
			MenuPresenter item = (MenuPresenter) ref.get();
			if (item == null || item == presenter) {
				mPresenters.remove(ref);
			}
		}
	}

	public void restoreActionViewStates(Bundle states) {
		if (states == null) {
		} else {
			SparseArray<Parcelable> viewStates = states.getSparseParcelableArray(getActionViewStatesKey());
			int i = 0;
			while (i < size()) {
				MenuItem item = getItem(i);
				View v = MenuItemCompat.getActionView(item);
				if (v == null || v.getId() == -1) {
					if (!item.hasSubMenu()) {
						((SubMenuBuilder) item.getSubMenu()).restoreActionViewStates(states);
					}
					i++;
				} else {
					v.restoreHierarchyState(viewStates);
					if (!item.hasSubMenu()) {
						i++;
					} else {
						((SubMenuBuilder) item.getSubMenu()).restoreActionViewStates(states);
						i++;
					}
				}
			}
			int expandedId = states.getInt(EXPANDED_ACTION_VIEW_ID);
			if (expandedId > 0) {
				MenuItem itemToExpand = findItem(expandedId);
				if (itemToExpand != null) {
					MenuItemCompat.expandActionView(itemToExpand);
				}
			}
		}
	}

	public void restorePresenterStates(Bundle state) {
		dispatchRestoreInstanceState(state);
	}

	public void saveActionViewStates(Bundle outStates) {
		SparseArray<Parcelable> viewStates = null;
		int i = 0;
		while (i < size()) {
			MenuItem item = getItem(i);
			View v = MenuItemCompat.getActionView(item);
			if (v == null || v.getId() == -1) {
				if (!item.hasSubMenu()) {
					((SubMenuBuilder) item.getSubMenu()).saveActionViewStates(outStates);
				}
				i++;
			} else {
				if (viewStates == null) {
					viewStates = new SparseArray();
				}
				v.saveHierarchyState(viewStates);
				if (MenuItemCompat.isActionViewExpanded(item)) {
					outStates.putInt(EXPANDED_ACTION_VIEW_ID, item.getItemId());
				}
				if (!item.hasSubMenu()) {
					i++;
				} else {
					((SubMenuBuilder) item.getSubMenu()).saveActionViewStates(outStates);
					i++;
				}
			}
		}
		if (viewStates != null) {
			outStates.putSparseParcelableArray(getActionViewStatesKey(), viewStates);
		}
	}

	public void savePresenterStates(Bundle outState) {
		dispatchSaveInstanceState(outState);
	}

	public void setCallback(Callback cb) {
		mCallback = cb;
	}

	public void setCurrentMenuInfo(ContextMenuInfo menuInfo) {
		mCurrentMenuInfo = menuInfo;
	}

	public MenuBuilder setDefaultShowAsAction(int defaultShowAsAction) {
		mDefaultShowAsAction = defaultShowAsAction;
		return this;
	}

	void setExclusiveItemChecked(MenuItem item) {
		int group = item.getGroupId();
		int i = 0;
		while (i < mItems.size()) {
			MenuItem curItem = (MenuItemImpl) mItems.get(i);
			if (curItem.getGroupId() != group || !curItem.isExclusiveCheckable() || !curItem.isCheckable()) {
				i++;
			} else {
				boolean r4z;
				if (curItem == item) {
					r4z = true;
				} else {
					r4z = false;
				}
				curItem.setCheckedInt(r4z);
				i++;
			}
		}
	}

	public void setGroupCheckable(int group, boolean checkable, boolean exclusive) {
		int i = 0;
		while (i < mItems.size()) {
			MenuItemImpl item = (MenuItemImpl) mItems.get(i);
			if (item.getGroupId() == group) {
				item.setExclusiveCheckable(exclusive);
				item.setCheckable(checkable);
			}
			i++;
		}
	}

	public void setGroupEnabled(int group, boolean enabled) {
		int i = 0;
		while (i < mItems.size()) {
			MenuItemImpl item = (MenuItemImpl) mItems.get(i);
			if (item.getGroupId() == group) {
				item.setEnabled(enabled);
			}
			i++;
		}
	}

	public void setGroupVisible(int group, boolean visible) {
		boolean changedAtLeastOneItem = false;
		int i = 0;
		while (i < mItems.size()) {
			MenuItemImpl item = (MenuItemImpl) mItems.get(i);
			if (item.getGroupId() != group || !item.setVisibleInt(visible)) {
				i++;
			} else {
				changedAtLeastOneItem = true;
				i++;
			}
		}
		if (changedAtLeastOneItem) {
			onItemsChanged(true);
		}
	}

	protected MenuBuilder setHeaderIconInt(int iconRes) {
		setHeaderInternal(0, null, iconRes, null, null);
		return this;
	}

	protected MenuBuilder setHeaderIconInt(Drawable icon) {
		setHeaderInternal(0, null, 0, icon, null);
		return this;
	}

	protected MenuBuilder setHeaderTitleInt(int titleRes) {
		setHeaderInternal(titleRes, null, 0, null, null);
		return this;
	}

	protected MenuBuilder setHeaderTitleInt(CharSequence title) {
		setHeaderInternal(0, title, 0, null, null);
		return this;
	}

	protected MenuBuilder setHeaderViewInt(View view) {
		setHeaderInternal(0, null, 0, null, view);
		return this;
	}

	public void setOptionalIconsVisible(boolean visible) {
		mOptionalIconsVisible = visible;
	}

	public void setOverrideVisibleItems(boolean override) {
		mOverrideVisibleItems = override;
	}

	public void setQwertyMode(boolean isQwerty) {
		mQwertyMode = isQwerty;
		onItemsChanged(false);
	}

	public void setShortcutsVisible(boolean shortcutsVisible) {
		if (mShortcutsVisible == shortcutsVisible) {
		} else {
			setShortcutsVisibleInner(shortcutsVisible);
			onItemsChanged(false);
		}
	}

	public int size() {
		return mItems.size();
	}

	public void startDispatchingItemsChanged() {
		mPreventDispatchingItemsChanged = false;
		if (mItemsChangedWhileDispatchPrevented) {
			mItemsChangedWhileDispatchPrevented = false;
			onItemsChanged(true);
		}
	}

	public void stopDispatchingItemsChanged() {
		if (!mPreventDispatchingItemsChanged) {
			mPreventDispatchingItemsChanged = true;
			mItemsChangedWhileDispatchPrevented = false;
		}
	}
}
