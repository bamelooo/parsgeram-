package android.support.v4.view;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;

public abstract class AbsSavedState implements Parcelable {
	public static final Creator<AbsSavedState> CREATOR;
	public static final AbsSavedState EMPTY_STATE;
	private final Parcelable mSuperState;

	static class AnonymousClass_1 extends AbsSavedState {
		AnonymousClass_1() {
			super(null);
		}
	}

	static class AnonymousClass_2 implements ParcelableCompatCreatorCallbacks<AbsSavedState> {
		AnonymousClass_2() {
			super();
		}

		public AbsSavedState createFromParcel(Parcel in, ClassLoader loader) {
			if (in.readParcelable(loader) != null) {
				throw new IllegalStateException("superState must be null");
			} else {
				return EMPTY_STATE;
			}
		}

		public AbsSavedState[] newArray(int size) {
			return new AbsSavedState[size];
		}
	}


	static {
		EMPTY_STATE = new AnonymousClass_1();
		CREATOR = ParcelableCompat.newCreator(new AnonymousClass_2());
	}

	private AbsSavedState() {
		super();
		mSuperState = null;
	}

	protected AbsSavedState(Parcel source) {
		this(source, null);
	}

	protected AbsSavedState(Parcel source, ClassLoader loader) {
		super();
		Parcelable superState = source.readParcelable(loader);
		if (superState != null) {
			mSuperState = superState;
		} else {
			superState = EMPTY_STATE;
			mSuperState = superState;
		}
	}

	protected AbsSavedState(Parcelable superState) {
		super();
		if (superState == null) {
			throw new IllegalArgumentException("superState must not be null");
		} else if (superState != EMPTY_STATE) {
			mSuperState = superState;
		} else {
			superState = null;
			mSuperState = superState;
		}
	}

	/* synthetic */ AbsSavedState(AnonymousClass_1 x0) {
		this();
	}

	public int describeContents() {
		return 0;
	}

	public final Parcelable getSuperState() {
		return mSuperState;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeParcelable(mSuperState, flags);
	}
}
