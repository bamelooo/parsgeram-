package android.support.v4.view;

import android.view.View;

public interface OnApplyWindowInsetsListener {
	public WindowInsetsCompat onApplyWindowInsets(View r1_View, WindowInsetsCompat r2_WindowInsetsCompat);
}
