package a.a.a.a;

import android.util.LruCache;

final class e extends LruCache {
	e(int r1i) {
		super(r1i);
	}

	private boolean a(Class r6_Class) {
		if (r6_Class == null) {
			return false;
		} else {
			Class[] r2_Class_A = r6_Class.getInterfaces();
			if (r2_Class_A != null) {
				if (r2_Class_A.length != 0) {
					int r1i = 0;
					while (r1i < r2_Class_A.length) {
						if (!d.a(r2_Class_A[r1i].getName())) {
							return true;
						} else {
							r1i++;
						}
					}
					return false;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
	}

	protected Boolean a(String r4_String) {
		Class r0_Class;
		Boolean r0_Boolean;
		try {
			r0_Class = Class.forName(r4_String);
			if (a(r0_Class)) {
				r0_Boolean = Boolean.valueOf(true);
				return r0_Boolean;
			} else {
				r0_Class = r0_Class.getSuperclass();
				while (r0_Class != null) {
					if (!d.a(r0_Class.getName()) || a(r0_Class)) {
						r0_Boolean = Boolean.valueOf(true);
						return r0_Boolean;
						return r0_Boolean;
					} else {
						r0_Class = r0_Class.getSuperclass();
					}
				}
				r0_Boolean = Boolean.valueOf(false);
				return r0_Boolean;
			}
		} catch (Exception e) {
			r0_Boolean = Boolean.valueOf(false);
		}
	}

	protected /* synthetic */ Object create(Object r2_Object) {
		return a((String) r2_Object);
	}
}
