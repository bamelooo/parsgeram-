package a.a.a.a;

public final class a {
	private a() {
		super();
	}

	public static void a_(String r1_String) {
		b.b().a(r1_String);
	}

	public static void a_(String r1_String, Object ... r2_Object_A) {
		b.b().b(r1_String, r2_Object_A);
	}

	public static void a_(Throwable r1_Throwable) {
		b.b().a(r1_Throwable);
	}

	public static void b(String r1_String) {
		b.b().b(r1_String);
	}
}
