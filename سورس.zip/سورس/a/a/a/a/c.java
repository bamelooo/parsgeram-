package a.a.a.a;

import a.a.a.a.b.a;
import android.text.TextUtils;
import com.rey.material.R;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.telegram.SQLite.SQLiteCursor;
import org.telegram.tgnet.ConnectionsManager;
import org.telegram.tgnet.TLRPC;

public abstract class c {
	private final List a;

	protected c() {
		super();
		a = new ArrayList();
		a.add(new a());
	}

	private static String e(String r1_String, Object[] r2_Object_A) {
		if (r1_String == null) {
			return "null";
		} else {
			return String.format(Locale.US, r1_String, r2_Object_A);
		}
	}

	protected abstract String a();

	protected void a(int r3i, String r4_String, Throwable r5_Throwable) {
		if (TextUtils.isEmpty(r4_String)) {
			r4_String = "empty message";
		}
		b.a(r3i, a(), r4_String, r5_Throwable, b());
	}

	public void a(String r3_String) {
		a((int)TLRPC.USER_FLAG_LAST_NAME, r3_String, null);
	}

	public void a(String r4_String, Object ... r5_Object_A) {
		a((int)ConnectionsManager.ConnectionStateConnected, e(r4_String, r5_Object_A), null);
	}

	public void a(Throwable r3_Throwable) {
		if (r3_Throwable == null) {
			r3_Throwable = new Exception("null exception logged");
		}
		a((int)SQLiteCursor.FIELD_TYPE_NULL, r3_Throwable.getMessage(), r3_Throwable);
	}

	public void a(Throwable r3_Throwable, String r4_String, Object ... r5_Object_A) {
		a((int)R.styleable.YearPicker_dp_textHighlightColor, e(r4_String, r5_Object_A), r3_Throwable);
	}

	protected synchronized List b() {
		synchronized(this) {
			return a;
		}
	}

	public void b(String r3_String) {
		a((int)SQLiteCursor.FIELD_TYPE_NULL, r3_String, null);
	}

	public void b(String r4_String, Object ... r5_Object_A) {
		a((int)TLRPC.USER_FLAG_LAST_NAME, e(r4_String, r5_Object_A), null);
	}

	public void b(Throwable r3_Throwable) {
		if (r3_Throwable == null) {
			r3_Throwable = new Exception("null exception logged");
		}
		a((int)R.styleable.YearPicker_dp_textHighlightColor, r3_Throwable.getMessage(), r3_Throwable);
	}

	public void c_(String r3_String) {
		a((int)R.styleable.YearPicker_dp_textHighlightColor, r3_String, null);
	}

	public void c_(String r4_String, Object ... r5_Object_A) {
		a((int)SQLiteCursor.FIELD_TYPE_NULL, e(r4_String, r5_Object_A), null);
	}

	public void d(String r4_String, Object ... r5_Object_A) {
		a((int)R.styleable.YearPicker_dp_textHighlightColor, e(r4_String, r5_Object_A), null);
	}
}
