package a.a.a.a.b;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

public interface b {
	public void a(int r1i, @NonNull String r2_String, @NonNull String r3_String, @Nullable Throwable r4_Throwable);
}
