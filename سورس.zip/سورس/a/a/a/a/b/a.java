package a.a.a.a.b;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

public class a implements b {
	public a() {
		super();
	}

	public void a_(int r3i, @NonNull String r4_String, @NonNull String r5_String, @Nullable Throwable r6_Throwable) {
		if (r6_Throwable != null) {
			r5_String = r5_String + '\n' + Log.getStackTraceString(r6_Throwable);
		}
		Log.println(r3i, r4_String, r5_String);
	}
}
