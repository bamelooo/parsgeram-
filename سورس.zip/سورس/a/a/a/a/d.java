package a.a.a.a;

import android.util.LruCache;
import org.telegram.tgnet.ConnectionsManager;

public final class d {
	private static final String a;
	private static final LruCache b;

	static {
		a = a.class.getPackage().getName();
		b = new e(100);
	}

	/* JADX WARNING: inconsistent code */
	/*
	public static java.lang.String a() {
		r0 = java.lang.Thread.currentThread();
		r2 = r0.getStackTrace();
		r0 = 3;
	L_0x0009:
		r1 = r2.length;
		if (r0 >= r1) goto L_0x0023;
	L_0x000c:
		r1 = r2[r0];
		r1 = r1.getClassName();
		r3 = a(r1);
		if (r3 == 0) goto L_0x0020;
	L_0x0018:
		r3 = c(r1);
		if (r3 != 0) goto L_0x0020;
	L_0x001e:
		r0 = r1;
	L_0x001f:
		return r0;
	L_0x0020:
		r0++;
		goto L_0x0009;
	L_0x0023:
		r0 = "Cat";
		goto L_0x001f;
	}
	*/
	public static String a() {
		StackTraceElement[] r2_StackTraceElement_A = Thread.currentThread().getStackTrace();
		int r0i = ConnectionsManager.ConnectionStateConnected;
		while (r0i < r2_StackTraceElement_A.length) {
			String r1_String = r2_StackTraceElement_A[r0i].getClassName();
			if (!a(r1_String) || c(r1_String)) {
				r0i++;
			}
		}
		return "Cat";
	}

	public static boolean a(String r1_String) {
		if (!r1_String.startsWith(a)) {
			return true;
		} else {
			return false;
		}
	}

	public static String b() {
		return b(a());
	}

	public static String b(String r2_String) {
		String[] r0_String_A = r2_String.split("\\.");
		if (r0_String_A.length == 0) {
			return r2_String;
		} else {
			return r0_String_A[r0_String_A.length - 1];
		}
	}

	public static String c() {
		String r0_String = a();
		String[] r1_String_A = r0_String.split("\\.");
		if (r1_String_A.length <= 1) {
			return r0_String;
		} else {
			return r0_String.substring(0, (r0_String.length() - 1) - r1_String_A[r1_String_A.length - 1].length());
		}
	}

	private static boolean c(String r1_String) {
		return ((Boolean) b.get(r1_String)).booleanValue();
	}
}
