package a.a.a.a.a;

import a.a.a.a.c;
import a.a.a.a.d;

public class a extends c {
	public a() {
		super();
	}

	protected String a_() {
		return d.b();
	}
}
