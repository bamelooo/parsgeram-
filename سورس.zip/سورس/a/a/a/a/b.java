package a.a.a.a;

import a.a.a.a.a.a;
import android.support.annotation.NonNull;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class b {
	private static final Set a;
	private static final List b;
	private static c c;
	private static final Map d;
	private static final List e;

	static {
		a = new HashSet();
		b = new ArrayList();
		c = new a();
		d = new HashMap();
		e = new ArrayList();
	}

	static synchronized void a(int r3i, String r4_String, String r5_String, Throwable r6_Throwable, List r7_List) {
		synchronized(b.class) {
			if (a.isEmpty() || !a.contains(r4_String)) {
				if ((b.isEmpty() || !a()) && r7_List != null && !r7_List.isEmpty()) {
					int r1i = 0;
					while (r1i < r7_List.size()) {
						((a.a.a.a.b.b) r7_List.get(r1i)).a(r3i, r4_String, r5_String, r6_Throwable);
						r1i = r1i + 1;
					}
				}
			}
		}
	}

	public static synchronized void a(@NonNull String r2_String, c r3_c) {
		synchronized(b.class) {
			d.put(r2_String, r3_c);
			e.add(r2_String);
		}
	}

	public static boolean a() {
		String r3_String = d.c();
		int r1i = 0;
		while (r1i < b.size()) {
			if (r3_String.startsWith((String) b.get(r1i))) {
				return true;
			} else {
				r1i = r1i + 1;
			}
		}
		return false;
	}

	static synchronized c b_() {
		synchronized(b.class) {
			c r0_c;
			if (!e.isEmpty()) {
				String r3_String = d.c();
				int r1i = e.size() - 1;
				while (r1i >= 0) {
					String r0_String = (String) e.get(r1i);
					if (r3_String.startsWith(r0_String)) {
						r0_c = (c) d.get(r0_String);
						return r0_c;
					} else {
						r1i = r1i - 1;
					}
				}
				r0_c = c;
			} else {
				r0_c = c;
			}
			return r0_c;
		}
	}
}
